<div class="sidebar">
    <?php if(auth()->guard()->check()): ?>
    <nav class="nav flex-column">
    <a class="nav-link fw-bold mb-3 <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('dashboard')); ?>"><i class="fa-solid fa-gauge-high me-2"></i> Dashbord</a>
    <p class="my-3 mx-3 border-bottom">App</p> 
    <a class="nav-link fw-bolder <?php echo e(Request::is('user/region*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('user.region.index')); ?>"><i class="fa-regular fa-map me-2"></i> Region</a>
    <a class="nav-link fw-bolder <?php echo e(Request::is('user/branch*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('user.branch.index')); ?>"><i class="fa-solid fa-map-pin me-3"></i> Branch</a>   
    <a class="nav-link fw-bolder <?php echo e(Request::is('user/staff*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('user.staff.index')); ?>"><i class="fa-solid fa-user-tie me-2"></i> Staff</a>
    <a class="nav-link fw-bolder <?php echo e(Request::is('user/data*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('user.data.index')); ?>"><i class="fa-solid fa-database me-2"></i> Data info</a>
    <a class="nav-link fw-bolder <?php echo e(Request::is('user/profile*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('user.profile.index')); ?>"><i class="fa-solid fa-gear me-2"></i></i> Setting</a>
    
    
    </nav>
    <?php elseif(auth()->guard('admin')->check()): ?>
    <nav class="nav flex-column">
    <a class="nav-link fw-bold mb-3 <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa-solid fa-gauge-high me-2"></i> Dashbord</a>
    <a class="nav-link fw-bolder <?php echo e(Request::is('admin/region*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('admin.region.index')); ?>"><i class="fa-regular fa-map me-2"></i> Region</a>
    <a class="nav-link fw-bolder <?php echo e(Request::is('admin/branch*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('admin.branch.index')); ?>"><i class="fa-solid fa-map-pin me-3"></i> Branch</a>
    <a class="nav-link fw-bolder <?php echo e(Request::is('admin/manager*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('admin.manager.index')); ?>"><i class="fa-solid fa-user-tie me-2"></i> Branch Manager</a>
    </nav>        
    <?php endif; ?>
    
</div><?php /**PATH C:\xampp\htdocs\laravel\heedbanglades\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>