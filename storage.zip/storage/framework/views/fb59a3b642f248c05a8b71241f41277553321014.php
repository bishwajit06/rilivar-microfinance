

<?php $__env->startSection('title','Category'); ?>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card p-0 p-md-4 shadow border-0">
                <div class="card-header bg-white border-0">
                    <div class="d-flex">
                        <h5>Branch</h5>
                        <div class="ms-auto">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary px-3" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        Add branch <i class="fa-solid fa-circle-plus"></i>
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content p-4">
                                    <form action="<?php echo e(route('user.branch.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header border-0">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Create branch</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="region_id" class="form-label">Region Name</label>
                                                <select class="form-select bg-light" aria-label="Default select example" name="region_id" id="region_id" required>
                                                    <option value="" selected>Select...</option>
                                                    <?php $__currentLoopData = App\Models\Region::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <input type="text" class="form-control" name="name" placeholder="Enter branch name">
                                            </div>
                                        </div>
                                        <div class="modal-footer border-0">
                                            <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Create branch</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="card-body">
                    
                    <table class="table table-striped">
                        <thead>
                            <tr>
                            <th>#SN</th>
                            <th>Branch name</th>
                            <th>Under Region</th>
                            <th>Branch Slug</th>
                            <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><?php echo e($branch->name); ?></td>
                                    <td><?php echo e($branch->region->name); ?></td>
                                    <td><?php echo e($branch->slug); ?></td>
                                    <td class="text-end">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($branch->slug); ?>">
                                    Edit
                                    </button>
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal<?php echo e($branch->slug); ?>" tabindex="-1" aria-labelledby="exampleModal<?php echo e($branch->slug); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content p-4">
                                                <form action="<?php echo e(route('user.branch.update',$branch->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModal<?php echo e($branch->slug); ?>Label">Update branch</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body text-start">
                                                        <div class="mb-3">
                                                            <label for="region_id" class="form-label">Region Name</label>
                                                            <select class="form-select bg-light" aria-label="Default select example" name="region_id" id="region_id" required>
                                                                <?php $__currentLoopData = App\Models\Region::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option 
                                                                        <?php echo e($branch->region_id ==  $region->id ? 'selected' : ''); ?>

                                                                    value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="region_id" class="form-label">Branch Name</label>
                                                            <input type="text" class="form-control" name="name" value="<?php echo e($branch->name); ?>" placeholder="Category name">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Update branch</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="btn btn-danger btn-sm" type="button" onclick="deleteBranch(<?php echo e($branch->id); ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">Delete</button>
                                    <form id="delete-form-<?php echo e($branch->id); ?>" action="<?php echo e(route('user.branch.destroy',$branch->id)); ?>" method="post" style="display:none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?> 
   
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        function deleteBranch(id) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-' + id).submit();
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\heedbanglades\resources\views/user/branch/index.blade.php ENDPATH**/ ?>