<?php if(auth()->guard()->check()): ?>
<header class="header">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-md-12">
          <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand fw-bold text-primary" href="<?php echo e(route('home')); ?>"><img style="height: 30px" class="px-3" src="<?php echo e(asset('assets/img/logo-2.png')); ?>" alt="Logo Image"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <div class="ms-auto">
                  <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          <?php
                            $user = App\Models\User::find(Auth::id());
                          ?>
                          <?php if($user->image): ?>
                          <img style="height:30px;" class="rounded-circle" src="<?php echo e(asset('storage/profile/'.$user->image)); ?>" alt="" />
                          <?php else: ?>
                          <img style="height:30px;" class="rounded-circle" src="<?php echo e(asset('assets/img/profile.jpg')); ?>" alt="" />
                          <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu border-0 shadow rounded-0">
                          <li class="mb-2"><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                          <li class="mb-2"><a class="dropdown-item" href="<?php echo e(route('user.profile.index')); ?>">Profile</a></li>
                          <li class="mb-2">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a class="dropdown-item pt-0" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">Logout</a>
                            </form>
                          </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
          </nav>
        </div>
      </div>
    </div>
</header>
<?php elseif(auth()->guard('admin')->check()): ?>
<header class="header">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-md-12">
          <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand fw-bold text-primary" href="#"><img style="height: 30px" class="px-3" src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="Logo Image"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <div class="ms-auto">
                  <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          <?php
                            $admin = App\Models\Admin::find(Auth::guard('admin')->user()->id);
                          ?>
                          <?php if($admin->image): ?>
                          <img style="height: 30px" class="rounded-circle" src="<?php echo e(asset('storage/profile/'.$admin->image)); ?>" alt="" />
                          <?php else: ?>
                          <img style="height: 30px" class="rounded-circle" src="<?php echo e(asset('assets/img/profile.jpg')); ?>" alt="" />
                          <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu border-0 shadow rounded-0">
                          <li><a class="dropdown-item" href="<?php echo e(route('admin.profile.index')); ?>">Profile</a></li>
                          <li>
                            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a class="dropdown-item pt-0" href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">Logout</a>
                            </form>
                          </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
          </nav>
        </div>
      </div>
    </div>
</header>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\heedbanglades\resources\views/layouts/partial/header.blade.php ENDPATH**/ ?>