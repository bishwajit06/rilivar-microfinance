

<?php $__env->startSection('title','Category'); ?>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card p-0 p-md-4 shadow border-0">
            <div class="card-header bg-white border-0">
                <div class="d-flex">
                    <h5>All Staff</h5>
                    <div class="ms-auto">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary px-3" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Add staff <i class="fa-solid fa-circle-plus"></i>
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content p-4">
                                <form action="<?php echo e(route('user.staff.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header border-0">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Create staff</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="name" class="form-label">Staff Name</label>
                                                    <input type="text" class="form-control" id="name" name="name" placeholder="staff name" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="phone" class="form-label">Phone</label>
                                                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="region_id" class="form-label">Region Name</label>
                                                    <select class="form-select bg-light" aria-label="Default select example" name="region_id" id="region_id" required>
                                                        <option value="" selected>Select...</option>
                                                        <?php $__currentLoopData = App\Models\Region::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="branch_id" class="form-label">Branch Name</label>
                                                    <select class="form-select bg-light" aria-label="Default select example" name="branch_id" id="branch_id" required>
                                                        <option value="" selected>Select...</option>
                                                        <?php $__currentLoopData = App\Models\Branch::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer border-0">
                                        <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Create branch</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                        <th>#SN</th>
                        <th width="3%">ID</th>
                        <th>Staff name</th>
                        <th>Region</th>
                        <th>Branch</th>
                        <th>Phone</th>
                        <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key+1); ?></th>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->Region->name); ?></td>
                                <td><?php echo e($item->branch->name); ?></td>
                                <td><?php echo e($item->phone); ?></td>
                                <td class="text-end">
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($item->id); ?>">
                                <i class="fa-regular fa-pen-to-square"></i>
                                </button>
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModal<?php echo e($item->id); ?>Label" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content p-4">
                                            <form action="<?php echo e(route('user.staff.update',$item->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModal<?php echo e($item->id); ?>Label">Update staff</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-start">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <div class="mb-3">
                                                                <label for="name" class="form-label">Staff Name</label>
                                                                <input type="text" class="form-control" id="name" name="name" placeholder="staff name" value="<?php echo e($item->name); ?>" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="mb-3">
                                                                <label for="phone" class="form-label">Phone</label>
                                                                <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" value="<?php echo e($item->phone); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="mb-3">
                                                                <label for="region_id" class="form-label">Region Name</label>
                                                                <select class="form-select bg-light" aria-label="Default select example" name="region_id" id="region_id" required>
                                                                    <?php $__currentLoopData = App\Models\Region::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option 
                                                                            <?php echo e($item->region_id ==  $region->id ? 'selected' : ''); ?>

                                                                        value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="mb-3">
                                                                <label for="branch_id" class="form-label">Branch Name</label>
                                                                <select class="form-select bg-light" aria-label="Default select example" name="branch_id" id="branch_id" required>
                                                                    <?php $__currentLoopData = App\Models\Branch::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option 
                                                                            <?php echo e($item->branch_id ==  $branch->id ? 'selected' : ''); ?>

                                                                        value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Update Staff</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-danger btn-sm" type="button" onclick="deleteStaff(<?php echo e($item->id); ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="fa-regular fa-trash-can"></i></button>
                                <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('user.staff.destroy',$item->id)); ?>" method="post" style="display:none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                                <a href="<?php echo e(route('user.staff.show',$item->id)); ?>" class="btn btn-primary btn-sm">Target <i class="fa-solid fa-bullseye"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="row row-cols-1 row-cols-lg-4 g-3">
        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-3"><?php echo e($item->name); ?></h5>
                    <div class="d-flex mb-3">
                        <img style="height: 80px" src="<?php echo e(asset('assets/img/profile.jpg')); ?>" alt="<?php echo e($item->name); ?> image">
                        <div class="align-self-center ms-3">
                            <p class="mb-1"><?php echo e($item->Region->name); ?></p>
                            <p class="mb-1"><?php echo e($item->branch->name); ?></p>
                            <p class="mb-1"><i class="fa-solid fa-phone-volume"></i> <?php echo e($item->phone); ?></p>
                        </div>
                    </div>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($item->id); ?>">
                    <i class="fa-regular fa-pen-to-square"></i>
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModal<?php echo e($item->id); ?>Label" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content p-4">
                                <form action="<?php echo e(route('user.staff.update',$item->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModal<?php echo e($item->id); ?>Label">Update staff</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-start">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="name" class="form-label">Staff Name</label>
                                                    <input type="text" class="form-control" id="name" name="name" placeholder="staff name" value="<?php echo e($item->name); ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="phone" class="form-label">Phone</label>
                                                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" value="<?php echo e($item->phone); ?>">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="region_id" class="form-label">Region Name</label>
                                                    <select class="form-select bg-light" aria-label="Default select example" name="region_id" id="region_id" required>
                                                        <?php $__currentLoopData = App\Models\Region::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option 
                                                                <?php echo e($item->region_id ==  $region->id ? 'selected' : ''); ?>

                                                            value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label for="branch_id" class="form-label">Branch Name</label>
                                                    <select class="form-select bg-light" aria-label="Default select example" name="branch_id" id="branch_id" required>
                                                        <?php $__currentLoopData = App\Models\Branch::where('user_id', Auth::id())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option 
                                                                <?php echo e($item->branch_id ==  $branch->id ? 'selected' : ''); ?>

                                                            value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Update Staff</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-danger btn-sm" type="button" onclick="deleteStaff(<?php echo e($item->id); ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="fa-regular fa-trash-can"></i></button>
                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('user.staff.destroy',$item->id)); ?>" method="post" style="display:none;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                    <a href="<?php echo e(route('user.staff.show',$item->id)); ?>" class="btn btn-primary btn-sm ms-auto">Target <i class="fa-solid fa-bullseye"></i></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?> 
   
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        function deleteStaff(id) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-' + id).submit();
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\heedbanglades\resources\views/user/staff/index.blade.php ENDPATH**/ ?>