
<?php $__env->startSection('title','User | Dashboard'); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row g-3">
        <div class="col-md-4 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-2">
                <div class="card-body">
                    <h5>Total Region</h5>
                    <div class="d-flex align-items-center">
                        <div class="">
                            <h2 class="h1"><?php echo e(App\Models\Region::where('user_id', Auth::id())->count()); ?></h2>
                            <a href="<?php echo e(route('user.region.index')); ?>" class="btn btn-light text-primary btn-sm shadow-sm rounded-1">More details</a>
                        </div>
                        <div class="ms-auto">
                            <img src="<?php echo e(asset('assets/img/region.png')); ?>" alt="branch-manager" style="height: 80px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-2">
                <div class="card-body">
                    <h5>Total Branch</h5>
                    <div class="d-flex align-items-center">
                        <div class="">
                            <h2 class="h1"><?php echo e(App\Models\Branch::where('user_id', Auth::id())->count()); ?></h2>
                            <a href="<?php echo e(route('user.branch.index')); ?>" class="btn btn-light text-primary btn-sm shadow-sm rounded-1">More details</a>
                        </div>
                        <div class="ms-auto">
                            <img src="<?php echo e(asset('assets/img/branch.png')); ?>" alt="branch-manager" style="height: 80px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-3">
            <div class="card border-0 shadow-sm h-100 p-2">
                <div class="card-body">
                    <h5>Total Staff</h5>
                    <div class="d-flex align-items-center">
                        <div class="">
                            <h2 class="h1"><?php echo e(App\Models\Staff::where('user_id', Auth::id())->count()); ?></h2>
                            <a href="<?php echo e(route('user.staff.index')); ?>" class="btn btn-light text-primary btn-sm shadow-sm rounded-1">More details</a>
                        </div>
                        <div class="ms-auto">
                            <img src="<?php echo e(asset('assets/img/staff.png')); ?>" alt="branch-manager" style="height: 100px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\heedbanglades\resources\views/user/dashboard.blade.php ENDPATH**/ ?>