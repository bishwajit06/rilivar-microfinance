<a href="{{route('home')}}"><img class="px-3" src="{{asset('assets/img/logo.png')}}" alt="Logo Image"></a>
