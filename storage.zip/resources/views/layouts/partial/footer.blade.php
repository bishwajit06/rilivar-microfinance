<div class="footer mt-5">
    <div class="container-fluid">
        <div class="d-flex">
            <p class="fw-light">© 2023-2024 Heed Banglades, Inc. | All right reserved</p>
            <p class="ms-auto" class="fw-light">v1.1.0</p>
        </div>
    </div>
</div>