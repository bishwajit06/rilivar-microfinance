<?php

namespace App\Http\Controllers;

use App\Models\Target;
use Brian2694\Toastr\Facades\Toastr;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TargetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $targets = Target::where('user_id', Auth::id())->orderBy('created_at', 'asc')->get();
        return view('user.target.index', compact('targets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        foreach ($request->id as $key => $data) {
            $input = [
                'id' => $request['id'][$key],
                'particular' => $request['particular'][$key],
                'p_june' => $request['p_june'][$key],
                'july' => $request['july'][$key],
                'august' => $request['august'][$key],
                'september' => $request['september'][$key],
                'october' => $request['october'][$key],
                'november' => $request['november'][$key],
                'december' => $request['december'][$key],
                'january' => $request['january'][$key],
                'february' => $request['february'][$key],
                'march' => $request['march'][$key],
                'april' => $request['april'][$key],
                'may' => $request['may'][$key],
                'june' => $request['june'][$key],
                'ac_july' => $request['ac_july'][$key],
                'ac_august' => $request['ac_august'][$key],
                'ac_september' => $request['ac_september'][$key],
                'ac_october' => $request['ac_october'][$key],
                'ac_november' => $request['ac_november'][$key],
                'ac_december' => $request['ac_december'][$key],
                'ac_january' => $request['ac_january'][$key],
                'ac_february' => $request['ac_february'][$key],
                'ac_march' => $request['ac_march'][$key],
                'ac_april' => $request['ac_april'][$key],
                'ac_may' => $request['ac_may'][$key],
                'ac_june' => $request['ac_june'][$key],
            ];

            DB::table('targets')->where('id', $request->id[$key])->update($input);

            if ($request->id[$key] == NULL) {
                    Target::create([
                    'user_id' => Auth::id(),
                    'staff_id' => $request->staff_id,
                    'particular' => $request['particular'][$key],
                    'p_june' => $request['p_june'][$key],
                    'july' => $request['july'][$key],
                    'august' => $request['august'][$key],
                    'september' => $request['september'][$key],
                    'october' => $request['october'][$key],
                    'november' => $request['november'][$key],
                    'december' => $request['december'][$key],
                    'january' => $request['january'][$key],
                    'february' => $request['february'][$key],
                    'march' => $request['march'][$key],
                    'april' => $request['april'][$key],
                    'may' => $request['may'][$key],
                    'june' => $request['june'][$key],
                    'ac_july' => $request['ac_july'][$key],
                    'ac_august' => $request['ac_august'][$key],
                    'ac_september' => $request['ac_september'][$key],
                    'ac_october' => $request['ac_october'][$key],
                    'ac_november' => $request['ac_november'][$key],
                    'ac_december' => $request['ac_december'][$key],
                    'ac_january' => $request['ac_january'][$key],
                    'ac_february' => $request['ac_february'][$key],
                    'ac_march' => $request['ac_march'][$key],
                    'ac_april' => $request['ac_april'][$key],
                    'ac_may' => $request['ac_may'][$key],
                    'ac_june' => $request['ac_june'][$key],
                ]);
            }
        } 


        Toastr::success('The Target and Achievement has been successfully created', 'Success');
        return redirect()->back();
    }

  
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        dd($id);

        $particular = $request->particular;
        $january = $request->january;
        $february = $request->february;
        $march = $request->march;
        $april = $request->april;
        $may = $request->may;
        $june = $request->june;
        $july = $request->july;
        $august = $request->august;
        $september = $request->september;
        $october = $request->october;
        $november = $request->november;
        $december = $request->december;

        for ($i=0; $i < count($particular); $i++) { 
            $data = [
                'user_id' => Auth::id(),
                'branch_id' => 4,
                'particular' => $particular[$i],
                'january' => $january[$i],
                'february' => $february[$i],
                'march' => $march[$i],
                'april' => $april[$i],
                'may' => $may[$i],
                'june' => $june[$i],
                'july' => $july[$i],
                'august' => $august[$i],
                'september' => $september[$i],
                'october' => $october[$i],
                'november' => $november[$i],
                'december' => $december[$i]
            ];

            Target::insert($data);
        }

        Toastr::success('The Target has been successfully created', 'Success');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
    }

    public function destroyTarget($id)
    {
        $target = Target::find($id);
        if (!is_null($target)){

            $target->delete();
            Toastr::success('The Target has been Successfully Deleted', 'Success');
            return redirect()->back();

        }else{
            return redirect()->back();
        }
    }
}
